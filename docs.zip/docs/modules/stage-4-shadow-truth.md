# Stage 4 — The Shadow of Truth

Fictional coma nightmare about a lie that harmed a coworker; no claim of religious punishment. Three short crossings over lethal lava use permanent solid platforms. Dark, flat silhouettes suggest unsupported routes. Before each crossing, a safe bank holds a brazier, three authored positions and a visible paired-bar placement clue. E at its handle cycles positions; the paired-bar position latches the solution, reveals paired bars along the real route and a brief memory. Wrong positions cost nothing. No shadow detection, projection, new ability or changing platform collision.

Memories: "I blamed Mara for the missing wages." / "Mara lost her job. Her family went without." / "I hid the signed receipt that proved I took them."

The third solution exposes the signed receipt on the departure bank. Use the existing carry/drop/return behaviour to take it across the last two stones to Mara's case file. Returning it acknowledges responsibility and opens the exit; all three solutions are required. Dropping in lava loses the evidence until the existing current-stage restart. Clues, memories and markings remain available to reread/retrace. Platforms have level tops, 0.67m gaps and 2m landing lengths, suitable for carrying jumps.

Saved scene: `Assets/HellSlice/Scenes/ShadowOfTruth.unity`. Stage 3 changes only its NextScene reference. StageNumber=4, SlowTimeUnlockStage=3; Space jump, Shift dodge and Q slow time remain unchanged. Exit applies the next reveal step and commits completion once. Death reloads the full scene, clearing solutions/carrying/receipt/gate/temporary abilities while retaining completed earlier stages. No Stage 5 destination yet.

Editing: `Level/Puzzles/Section 1–3` contains each fixed handle, movable brazier, position anchors, markings and memory. `SliceTruthBrazier` exposes those references, correct position, range, prerequisite and memory. Platform meshes/colliders stay under Environment. `SliceShadowTruthStage` on Gameplay Session references the three sections, receipt and exit gate. The receipt uses `SliceValuable` with editable receptacle/placement references. No runtime level construction or new editor commands.

Verification: compile runtime/editor sources; check serialized references, scene preservation, build inclusion, input and jump clearance; exercise puzzle ordering, evidence return, completion deduplication and restart/progress boundaries. Manual scene import, rendering, physical traversal and full playthrough remain required; see `docs/qa/stage-4-shadow-truth.md`.
